/* Données de départ : catégories, les deux produits, le slider et le compte admin.
   Usage : DATABASE_URL=... ADMIN_PASSWORD=... npm run db:seed */
import bcrypt from 'bcryptjs';
import { db, schema } from '../src/db';

async function main() {
  const existing = await db.select().from(schema.products).limit(1);
  if (existing.length) {
    console.log('La base contient déjà des produits : rien à faire.');
    process.exit(0);
  }

  const cats = await db.insert(schema.categories).values([
    { name: 'Nouveautés', slug: 'nouveautes', image: '/images/curieux.jpg', position: 0 },
    { name: 'Les sets', slug: 'sets', image: '/images/indice-couleurs.jpg', position: 1 },
    { name: 'Les robes', slug: 'robes', image: '/images/robe-fleurie.jpg', position: 2 },
    { name: 'Les blouses', slug: 'blouses', image: '/images/indice-details.jpg', position: 3 },
    { name: 'Les pantalons', slug: 'pantalons', image: '/images/indice-age.jpg', position: 4 },
    { name: 'Édition limitée', slug: 'edition-limitee', image: null, position: 5 },
  ]).returning();
  const c = Object.fromEntries(cats.map((x) => [x.slug, x.id]));

  const [set] = await db.insert(schema.products).values({
    slug: 'le-set', name: 'Le set', subtitle: 'Blouse 100 % coton · pantalon 100 % lin', price: 132,
    description: 'Une blouse blanche aux fronces tout en douceur, nouée d’un lien kaki dans le dos, et un pantalon en lin qui suit chaque mouvement. Un set pensé pour les journées douces de l’automne.',
    details: 'Blouse blanche 100 % coton, fronces et poignets élastiqués\nLiens en lin noués dans le dos\nPantalon kaki 100 % lin, poches plaquées et revers\nCousu avec soin en Tunisie',
    care: '', label: 'nouveau', materials: ['Coton', 'Lin'],
    colors: [{ name: 'Blanc', hex: '#FFFFFF' }, { name: 'Kaki', hex: '#A58B5E' }], published: true, position: 0,
  }).returning();

  const [robe] = await db.insert(schema.products).values({
    slug: 'la-robe-fleurie', name: 'La robe fleurie', subtitle: '100 % coton doublé · col volanté', price: 119,
    description: 'Une robe en coton doublé, au col volanté et aux manches froncées, fermée par de petits boutons au dos.',
    details: '100 % coton doublé\nCol volanté, manches froncées\nBoutons au dos\nÉdition limitée : 24 pièces',
    care: '', label: 'edition_limitee', materials: ['Coton'],
    colors: [{ name: 'Rose poudré', hex: '#E2C6CC' }, { name: 'Prune', hex: '#8D505A' }], published: true, position: 1,
  }).returning();

  await db.insert(schema.productImages).values([
    { productId: set.id, url: '/images/indice-couleurs.jpg', alt: 'Blouse blanche et pantalon kaki selima', position: 0 },
    { productId: set.id, url: '/images/slide-1.jpg', alt: 'Le set porté, de dos', position: 1 },
    { productId: set.id, url: '/images/indice-details.jpg', alt: 'Lien noué dans le dos de la blouse', position: 2 },
    { productId: set.id, url: '/images/indice-age.jpg', alt: 'Pantalon en lin porté', position: 3 },
    { productId: set.id, url: '/images/curieux.jpg', alt: 'Détail de la blouse', position: 4 },
    { productId: robe.id, url: '/images/robe-fleurie.jpg', alt: 'La robe fleurie portée et sur mannequin, de dos', position: 0 },
  ]);

  const sizes = ['2 ans', '3 ans', '4 ans', '5 ans', '6 ans'];
  const setStock = [6, 6, 6, 6, 6]; // stock du set : à confirmer
  const robeStock = [5, 5, 5, 5, 4]; // 24 pièces
  await db.insert(schema.productSizes).values([
    ...sizes.map((size, i) => ({ productId: set.id, size, stock: setStock[i], position: i })),
    ...sizes.map((size, i) => ({ productId: robe.id, size, stock: robeStock[i], position: i })),
  ]);

  await db.insert(schema.productCategories).values([
    { productId: set.id, categoryId: c['nouveautes'] },
    { productId: set.id, categoryId: c['sets'] },
    { productId: set.id, categoryId: c['blouses'] },
    { productId: set.id, categoryId: c['pantalons'] },
    { productId: robe.id, categoryId: c['nouveautes'] },
    { productId: robe.id, categoryId: c['robes'] },
    { productId: robe.id, categoryId: c['edition-limitee'] },
  ]);

  await db.insert(schema.slides).values([
    { url: '/images/slide-1.jpg', alt: 'Petite fille de dos en blouse blanche et pantalon kaki selima', position: 0 },
    { url: '/images/robe-fleurie.jpg', alt: 'La robe fleurie portée, de dos', position: 1 },
  ]);

  const password = process.env.ADMIN_PASSWORD || 'selima-a-changer';
  await db.insert(schema.adminUsers).values({ username: 'selima', passwordHash: await bcrypt.hash(password, 10) });

  console.log('Données de départ créées. Compte admin : selima /', process.env.ADMIN_PASSWORD ? '(mot de passe fourni)' : password);
  process.exit(0);
}

main().catch((e) => { console.error(e); process.exit(1); });
