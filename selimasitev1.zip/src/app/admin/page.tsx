// Espace de gestion : construit à la phase 2 du développement.
export const metadata = { title: 'Espace de gestion', robots: { index: false } };

export default function Admin() {
  return (
    <main style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Arial, sans-serif', background: '#F0F0F1' }}>
      <p style={{ background: '#fff', border: '1px solid #DCDCDE', padding: 24 }}>L’espace de gestion arrive à la prochaine étape.</p>
    </main>
  );
}
