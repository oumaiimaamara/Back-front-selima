import type { Metadata } from 'next';
import { CartProvider } from '@/components/cart';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL('https://selimaclothing.com'),
  title: { default: 'selima — L’enfance, avec élégance', template: '%s · selima' },
  description: 'selima, vêtements pour filles de 2 à 6 ans. Coton et lin, cousus avec soin en Tunisie.',
  icons: { icon: '/images/logo-selima.png' },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;500;600&family=Cormorant+Garamond:ital,wght@1,400;1,500&display=swap" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600&text=0123456789&display=swap" />
      </head>
      <body>
        <CartProvider>{children}</CartProvider>
      </body>
    </html>
  );
}
