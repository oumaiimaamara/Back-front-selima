import type { Metadata } from 'next';
import PanierView from '@/components/PanierView';
import { getSettings } from '@/lib/settings';

export const metadata: Metadata = { title: 'Mon panier', robots: { index: false } };

export default async function Panier() {
  const s = await getSettings();
  return <PanierView shippingFee={s.shippingFee} freeFrom={s.freeShippingFrom} shippingDelay={s.shippingDelay} />;
}
