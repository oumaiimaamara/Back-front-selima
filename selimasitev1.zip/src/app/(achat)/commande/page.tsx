import type { Metadata } from 'next';
import CommandeForm from '@/components/CommandeForm';
import { getSettings } from '@/lib/settings';

export const metadata: Metadata = { title: 'Livraison', robots: { index: false } };

export default async function Commande() {
  const s = await getSettings();
  return <CommandeForm shippingFee={s.shippingFee} freeFrom={s.freeShippingFrom} />;
}
