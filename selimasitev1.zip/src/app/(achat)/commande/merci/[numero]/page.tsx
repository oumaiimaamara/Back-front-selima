import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { eq } from 'drizzle-orm';
import { db, schema } from '@/db';
import { Coche } from '@/components/icons';
import { getSettings, instagramLink } from '@/lib/settings';

export const metadata: Metadata = { title: 'Merci', robots: { index: false } };

export default async function Merci({ params }: { params: { numero: string } }) {
  const [order] = await db.select().from(schema.orders).where(eq(schema.orders.number, params.numero)).limit(1);
  if (!order) notFound();
  const items = await db.select().from(schema.orderItems).where(eq(schema.orderItems.orderId, order.id));
  const settings = await getSettings();

  return (
    <main className="wrap-etroit" style={{ paddingTop: 72, paddingBottom: 96, maxWidth: 760, textAlign: 'center' }}>
      <span className="rond-rose" style={{ width: 72, height: 72, display: 'inline-flex' }}><Coche size={30} /></span>
      <h1 style={{ margin: '24px 0 0', fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 52, lineHeight: 1.1, fontWeight: 500, color: 'var(--titre)' }}>Merci {order.firstName}</h1>
      <p style={{ margin: '14px auto 0', maxWidth: 520, fontSize: 17, lineHeight: 1.6, color: 'var(--texte-doux)' }}>
        Votre commande <strong style={{ color: 'var(--texte)' }}>n° {order.number}</strong> est bien enregistrée. Nous la préparons avec soin, elle vous sera livrée sous {settings.shippingDelay}.
      </p>

      <div className="recap" style={{ marginTop: 36, textAlign: 'left' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {items.map((it) => (
            <div key={it.id} className="recap__ligne" style={{ color: 'var(--texte)' }}><span>{it.productName} · {it.size} × {it.quantity}</span><strong>{it.unitPrice * it.quantity} DT</strong></div>
          ))}
          <div className="recap__ligne"><span>Livraison</span><span>{order.shipping ? order.shipping + ' DT' : 'Offerte'}</span></div>
        </div>
        <div className="recap__total"><span style={{ fontSize: 18, fontWeight: 600 }}>À régler à la livraison</span><span style={{ fontSize: 18, fontWeight: 600 }}>{order.total} DT</span></div>
      </div>

      <div style={{ margin: '28px auto 0', maxWidth: 520, display: 'flex', flexDirection: 'column', gap: 10, fontSize: 15, textAlign: 'left' }}>
        <div style={{ display: 'flex', gap: 12 }}><span style={{ color: 'var(--or)', fontWeight: 600 }}>1.</span>Nous préparons votre commande.</div>
        <div style={{ display: 'flex', gap: 12 }}><span style={{ color: 'var(--or)', fontWeight: 600 }}>2.</span>Votre colis part dans sa pochette en coton écru.</div>
        <div style={{ display: 'flex', gap: 12 }}><span style={{ color: 'var(--or)', fontWeight: 600 }}>3.</span>Vous réglez en espèces à la réception.</div>
      </div>

      <div style={{ marginTop: 36, display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
        <Link href="/boutique" className="bouton-plein" style={{ height: 56, fontSize: 15 }}>Continuer mes achats</Link>
        <a href={instagramLink(settings)} target="_blank" rel="noopener" className="bouton-contour">Suivre @{settings.instagram}</a>
      </div>
    </main>
  );
}
