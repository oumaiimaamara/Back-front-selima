import Link from 'next/link';
import Etapes from '@/components/Etapes';
import { Bulle } from '@/components/icons';
import { getSettings, whatsappLink } from '@/lib/settings';

export const dynamic = 'force-dynamic';

export default async function AchatLayout({ children }: { children: React.ReactNode }) {
  const settings = await getSettings();
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <header style={{ borderBottom: '1px solid var(--trait)' }}>
        <div className="wrap-etroit achat-tete">
          <Link href="/" className="nav__marque" style={{ fontSize: 18 }}>
            <img src="/images/logo-selima.png" alt="" />selima
          </Link>
          <Etapes />
          <a href={whatsappLink(settings, 'Bonjour, j’ai besoin d’aide pour ma commande.')} target="_blank" rel="noopener" style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, fontWeight: 500, color: 'var(--titre)' }}>
            <Bulle size={18} /><span className="achat-masque">Besoin d’aide ?</span>
          </a>
        </div>
      </header>
      <div style={{ flex: 1 }}>{children}</div>
      <footer style={{ borderTop: '1px solid var(--trait)' }}>
        <div className="wrap-etroit" style={{ paddingTop: 24, paddingBottom: 24, display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12, fontSize: 13, color: 'var(--texte-doux)' }}>
          <span>© {new Date().getFullYear()} selima · Paiement à la livraison · Livraison partout en Tunisie</span>
          <span><Link href="/aide?rubrique=cgv">Conditions de vente</Link> · <a href={whatsappLink(settings)} target="_blank" rel="noopener">WhatsApp {settings.whatsapp}</a></span>
        </div>
      </footer>
    </div>
  );
}
