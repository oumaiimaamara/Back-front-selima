import Footer from '@/components/Footer';
import { getProducts } from '@/lib/catalog';
import { getSettings } from '@/lib/settings';

export const dynamic = 'force-dynamic';

export default async function BoutiqueLayout({ children }: { children: React.ReactNode }) {
  const settings = await getSettings();
  const products = await getProducts({ threshold: settings.lowStockThreshold });
  return (
    <>
      <div className="bandeau">{settings.announcement}</div>
      {children}
      <Footer settings={settings} products={products.map((p) => ({ slug: p.slug, name: p.name }))} />
    </>
  );
}
