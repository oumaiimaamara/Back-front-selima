import type { Metadata } from 'next';
import Link from 'next/link';
import CategoryRow from '@/components/CategoryRow';
import Header from '@/components/Header';
import ProductCard from '@/components/ProductCard';
import SortSelect from '@/components/SortSelect';
import { Fleche } from '@/components/icons';
import { getCategories, getProducts, SIZES } from '@/lib/catalog';
import { getSettings, instagramLink, whatsappLink } from '@/lib/settings';

export const metadata: Metadata = { title: 'La boutique' };

type SP = { categorie?: string; taille?: string; matiere?: string; tri?: string };

function lien(sp: SP, change: Partial<SP>) {
  const p = new URLSearchParams();
  const merged = { ...sp, ...change };
  (Object.keys(merged) as (keyof SP)[]).forEach((k) => { if (merged[k]) p.set(k, merged[k]!); });
  const q = p.toString();
  return '/boutique' + (q ? '?' + q : '');
}

export default async function Boutique({ searchParams }: { searchParams: SP }) {
  const settings = await getSettings();
  const [categories, products] = await Promise.all([
    getCategories(),
    getProducts({ category: searchParams.categorie, size: searchParams.taille, material: searchParams.matiere, sort: searchParams.tri, threshold: settings.lowStockThreshold }),
  ]);
  const cat = categories.find((c) => c.slug === searchParams.categorie);
  const filtres = [searchParams.taille, searchParams.matiere].filter(Boolean) as string[];

  return (
    <main>
      <header className="wrap" style={{ paddingTop: 24 }}><Header /></header>

      <section className="wrap" style={{ paddingTop: 56 }}>
        <div className="fil"><Link href="/">Accueil</Link> · {cat ? <><Link href="/boutique">La boutique</Link> · <span>{cat.name}</span></> : <span>La boutique</span>}</div>
        <h1 style={{ margin: '10px 0 0', fontSize: 56, lineHeight: 1.1, fontWeight: 500, color: 'var(--titre)' }} className="boutique-titre">{cat ? cat.name : 'La boutique'}</h1>
        <p style={{ margin: '10px 0 0', fontSize: 18, lineHeight: 1.5, maxWidth: 520, color: 'var(--texte-doux)' }}>Toutes nos pièces en coton et en lin, de 2 à 6 ans.</p>
      </section>

      <nav className="wrap" style={{ paddingTop: 44 }} aria-label="Catégories">
        <CategoryRow categories={categories} current={searchParams.categorie} small showAll />
      </nav>

      <section className="wrap" style={{ paddingTop: 44 }} aria-label="Filtres">
        <div className="filtres">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            <span className="filtres__label">Taille</span>
            {SIZES.map((t) => (
              <Link key={t} href={lien(searchParams, { taille: searchParams.taille === t ? undefined : t })} className="pilule" aria-pressed={searchParams.taille === t} scroll={false}>{t}</Link>
            ))}
            <span style={{ width: 1, height: 28, background: 'var(--trait)', margin: '0 8px' }} />
            <span className="filtres__label">Matière</span>
            {['Coton', 'Lin'].map((m) => (
              <Link key={m} href={lien(searchParams, { matiere: searchParams.matiere === m ? undefined : m })} className="pilule" aria-pressed={searchParams.matiere === m} scroll={false}>{m}</Link>
            ))}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <span style={{ fontSize: 14, color: 'var(--texte-doux)' }}>{products.length} pièce{products.length > 1 ? 's' : ''}</span>
            <SortSelect value={searchParams.tri ?? ''} />
          </div>
        </div>
        {filtres.length > 0 && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, paddingTop: 14, fontSize: 14, color: 'var(--texte-doux)' }}>
            <span>Filtres : {filtres.join(' · ')}</span>
            <Link href={lien(searchParams, { taille: undefined, matiere: undefined })} className="lien" scroll={false}>Tout effacer</Link>
          </div>
        )}
      </section>

      <section className="wrap" style={{ paddingTop: 32 }}>
        {products.length > 0 ? (
          <div className="g-produits-3">
            {products.map((p) => <ProductCard key={p.id} p={p} />)}
            {filtres.length === 0 && !searchParams.categorie && products.length < 3 && (
              <article className="carte-drop">
                <img src="/images/logo-selima.png" alt="" />
                <p className="carte-drop__titre">Le prochain drop se prépare…</p>
                <p style={{ margin: 0, fontSize: 15, lineHeight: 1.6, color: 'var(--texte-doux)' }}>Soyez les premières informées des nouvelles pièces.</p>
                <a href={instagramLink(settings)} target="_blank" rel="noopener" className="bouton" style={{ alignSelf: 'flex-start', height: 56 }}>
                  Suivre @{settings.instagram}
                  <span className="bouton__rond" style={{ width: 44, height: 44 }}><Fleche size={16} /></span>
                </a>
              </article>
            )}
          </div>
        ) : (
          <div style={{ borderRadius: 24, background: 'var(--carte-qualite)', padding: '64px 24px', textAlign: 'center' }}>
            <p style={{ margin: 0, fontSize: 20, fontWeight: 500, color: 'var(--titre)' }}>Aucune pièce ne correspond à ces filtres</p>
            <p style={{ margin: '8px 0 20px', fontSize: 15, color: 'var(--texte-doux)' }}>Essayez une autre taille, ou écrivez-nous : nous vous conseillons volontiers.</p>
            <Link href="/boutique" className="bouton-contour">Effacer les filtres</Link>
          </div>
        )}
      </section>

      <section className="wrap" style={{ paddingTop: 80 }}>
        <div className="aide-taille">
          <div>
            <p style={{ margin: 0, fontSize: 24, fontWeight: 500, color: 'var(--titre)' }}>Un doute sur la taille ?</p>
            <p style={{ margin: '6px 0 0', fontSize: 15, color: 'var(--texte-doux)' }}>Consultez le guide, ou écrivez-nous sur WhatsApp au {settings.whatsapp}.</p>
          </div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            <Link href="/aide?rubrique=tailles" className="bouton-contour">Guide des tailles</Link>
            <a href={whatsappLink(settings, 'Bonjour, j’hésite sur une taille.')} target="_blank" rel="noopener" className="bouton-plein" style={{ height: 56, fontSize: 15 }}>Nous écrire</a>
          </div>
        </div>
      </section>
    </main>
  );
}
