import Link from 'next/link';
import CategoryRow from '@/components/CategoryRow';
import Header from '@/components/Header';
import HeroSlider from '@/components/HeroSlider';
import ProductCard from '@/components/ProductCard';
import { Billet, Bulle, Camion, Coeur, Fleche, FlecheGras, Instagram } from '@/components/icons';
import { getCategories, getProducts, getSlides } from '@/lib/catalog';
import { getSettings, instagramLink } from '@/lib/settings';

export default async function Accueil() {
  const settings = await getSettings();
  const [slides, categories, products] = await Promise.all([
    getSlides(), getCategories(), getProducts({ threshold: settings.lowStockThreshold }),
  ]);
  const b = settings.homeBlocks;
  const vedette = products.slice(0, 2);

  return (
    <main>
      {/* HERO */}
      <section className="hero">
        <HeroSlider slides={slides.length ? slides : [{ url: '/images/slide-1.jpg', alt: '' }]} />
        <Header variant="photo" />
        <div className="verre">
          <div className="verre__surtitre">{settings.hero.kicker}</div>
          <h1>{settings.hero.title}</h1>
          <p>{settings.hero.text}</p>
          <div style={{ marginTop: 32 }}>
            <Link href={settings.hero.buttonHref} className="bouton">
              {settings.hero.buttonLabel}
              <span className="bouton__rond"><Fleche /></span>
            </Link>
          </div>
        </div>
      </section>

      {/* CATÉGORIES */}
      {b.categories && categories.length > 0 && (
        <nav className="wrap" style={{ paddingTop: 48 }} aria-label="Catégories">
          <CategoryRow categories={categories} />
        </nav>
      )}

      {/* LA COLLECTION */}
      {b.collection && (
        <section id="collection" className="wrap" style={{ paddingTop: 110 }}>
          <h2 className="titre">La collection</h2>
          <p className="sous-titre">Deux pièces pour la saison cocooning, pensées pour être portées, aimées, transmises.</p>
          <div className="g-produits-2" style={{ marginTop: 40 }}>
            {vedette.map((p) => <ProductCard key={p.id} p={p} height={620} />)}
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: 44 }}>
            <Link href="/boutique" className="bouton" style={{ border: '1.5px solid var(--texte)' }}>
              Voir toute la boutique
              <span className="rond-rose" style={{ width: 44, height: 44 }}><FlecheGras size={16} /></span>
            </Link>
          </div>
        </section>
      )}

      {/* MATIÈRES */}
      {b.materials && (
        <section id="matieres" className="wrap" style={{ paddingTop: 120 }}>
          <h2 className="titre">Le luxe commence par la matière</h2>
          <p className="sous-titre">Des tissus naturels, doux sur la peau, et des finitions où rien n’est laissé au hasard.</p>
          <div className="g-3" style={{ marginTop: 38 }}>
            <article className="carte-info">
              <img src="/images/indice-matieres.jpg" alt="Tissu de coton blanc en gros plan" />
              <span className="puce">Le coton</span>
              <p>Respirant, doux et hypoallergénique : il respecte les peaux les plus délicates.</p>
            </article>
            <article className="carte-info">
              <img src="/images/indice-age.jpg" alt="Petite fille de dos en pantalon de lin" style={{ objectPosition: '50% 30%' }} />
              <span className="puce">Le lin</span>
              <p>Souple, solide et durable : il suit chaque mouvement, saison après saison.</p>
            </article>
            <article className="carte-info">
              <img src="/images/indice-details.jpg" alt="Détail du lien noué dans le dos d’une blouse blanche" />
              <span className="puce">Les détails</span>
              <p>Un lien noué dans le dos, des fronces tout en douceur, des poignets qui tiennent.</p>
            </article>
          </div>
        </section>
      )}

      {/* CADEAU */}
      {b.gift && (
        <section className="wrap" style={{ paddingTop: 120 }}>
          <div className="accueil-cadeau">
            <img src="/images/logo-selima.png" alt="Logo selima, un iris lilas" />
            <div style={{ flex: 1 }}>
              <div className="surtitre">Chaque commande</div>
              <h2 style={{ margin: '12px 0 0', fontSize: 40, lineHeight: 1.2, fontWeight: 500, color: 'var(--titre)' }}>Comme un petit cadeau</h2>
              <p style={{ margin: '14px 0 0', maxWidth: 620, fontSize: 17, lineHeight: 1.6, color: 'var(--texte-doux)' }}>Chaque pièce arrive dans une pochette en coton écru, nouée d’un lien en lin et marquée de notre iris. Pour ce qu’ils ont de plus précieux.</p>
            </div>
          </div>
        </section>
      )}

      {/* POUR LES CURIEUX */}
      {b.faq && (
        <section id="curieux" className="wrap" style={{ paddingTop: 120 }}>
          <h2 className="titre">Pour les curieux</h2>
          <div className="accueil-faq">
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {settings.faq.map((f, i) => (
                <details key={i} className="repli" open={i === 0}>
                  <summary>{f.q}<span className="rond-rose"><FlecheGras /></span></summary>
                  <p>{f.a}</p>
                </details>
              ))}
            </div>
            <div className="accueil-faq__photo">
              <img src="/images/curieux.jpg" alt="Détail d’une blouse blanche en coton selima" />
            </div>
          </div>
        </section>
      )}

      {/* INSTAGRAM */}
      {b.instagram && (
        <section className="wrap" style={{ paddingTop: 120 }}>
          <div className="accueil-insta">
            <div>
              <p style={{ margin: 0, fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 34, lineHeight: 1.2, color: 'var(--espresso)' }}>Suivez les coulisses de selima</p>
              <p style={{ margin: '8px 0 0', fontSize: 16, color: 'var(--texte-doux)' }}>Nouveautés, matières et petites histoires sur @{settings.instagram}</p>
            </div>
            <a href={instagramLink(settings)} target="_blank" rel="noopener" className="bouton">
              Suivez-nous sur Instagram
              <span className="bouton__rond"><Instagram /></span>
            </a>
          </div>
        </section>
      )}

      {/* ENGAGEMENTS */}
      {b.commitments && (
        <section className="wrap" style={{ paddingTop: 56 }} aria-label="Nos engagements">
          <div className="g-4">
            {[
              { i: <Camion />, t: 'Livraison ' + settings.shippingDelay, d: 'Partout en Tunisie, ' + settings.shippingFee + ' DT.' },
              { i: <Billet />, t: 'Paiement à la livraison', d: 'Vous réglez en espèces à la réception.' },
              { i: <Coeur />, t: 'Made in Tunisia', d: 'Cousu avec soin, en petites séries.' },
              { i: <Bulle />, t: 'Conseil sur WhatsApp', d: 'Un doute sur la taille ? Écrivez-nous au ' + settings.whatsapp + '.' },
            ].map((e) => (
              <div key={e.t} className="engagement">
                <span className="rond-rose" style={{ width: 44, height: 44 }}>{e.i}</span>
                <strong>{e.t}</strong>
                <span>{e.d}</span>
              </div>
            ))}
          </div>
        </section>
      )}
    </main>
  );
}
