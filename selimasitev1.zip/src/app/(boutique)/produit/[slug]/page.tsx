import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import Header from '@/components/Header';
import ProductCard from '@/components/ProductCard';
import ProductView from '@/components/ProductView';
import { getOtherProducts, getProductBySlug } from '@/lib/catalog';
import { getSettings } from '@/lib/settings';

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const settings = await getSettings();
  const p = await getProductBySlug(params.slug, settings.lowStockThreshold);
  if (!p) return { title: 'Pièce introuvable' };
  return { title: p.name, description: p.description, openGraph: { images: p.image ? [p.image] : [] } };
}

export default async function Produit({ params }: { params: { slug: string } }) {
  const settings = await getSettings();
  const p = await getProductBySlug(params.slug, settings.lowStockThreshold);
  if (!p) notFound();
  const autres = await getOtherProducts(p.id, settings.lowStockThreshold);

  return (
    <main>
      <header className="wrap" style={{ paddingTop: 24 }}>
        <Header />
        <div className="fil" style={{ marginTop: 28 }}><Link href="/">Accueil</Link> · <Link href="/boutique">La boutique</Link> · <span>{p.name}</span></div>
      </header>

      <section className="wrap" style={{ paddingTop: 20 }}>
        <ProductView p={p} whatsapp={settings.whatsapp} shippingFee={settings.shippingFee} shippingDelay={settings.shippingDelay} threshold={settings.lowStockThreshold} />
      </section>

      <section className="wrap" style={{ paddingTop: 110 }}>
        <h2 className="titre" style={{ fontSize: 40 }}>Les détails qui comptent</h2>
        <div className="g-3" style={{ marginTop: 36 }}>
          {p.images.slice(1, 4).map((im) => (
            <article key={im.url} className="carte-info" style={{ height: 420 }}>
              <img src={im.url} alt={im.alt} style={{ objectPosition: '50% 30%' }} />
              <p>{im.alt}</p>
            </article>
          ))}
        </div>
      </section>

      {autres.length > 0 && (
        <section className="wrap" style={{ paddingTop: 110 }}>
          <h2 className="titre" style={{ fontSize: 40 }}>Vous aimerez aussi</h2>
          <div style={{ margin: '36px auto 0', maxWidth: autres.length === 1 ? 440 : 'none' }} className={autres.length > 1 ? 'g-produits-3' : ''}>
            {autres.map((o) => <ProductCard key={o.id} p={o} height={480} showMeta={false} />)}
          </div>
        </section>
      )}
    </main>
  );
}
