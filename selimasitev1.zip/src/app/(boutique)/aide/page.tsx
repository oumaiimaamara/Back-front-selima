import type { Metadata } from 'next';
import Link from 'next/link';
import ContactForm from '@/components/ContactForm';
import Header from '@/components/Header';
import SizeTable from '@/components/SizeTable';
import { getSettings, instagramLink, whatsappLink } from '@/lib/settings';

export const metadata: Metadata = { title: 'Aide' };

const RUBRIQUES = [
  { id: 'livraison', label: 'Livraison & paiement' },
  { id: 'echanges', label: 'Échanges' },
  { id: 'tailles', label: 'Guide des tailles' },
  { id: 'contact', label: 'Contact' },
  { id: 'cgv', label: 'Conditions de vente' },
];

export default async function Aide({ searchParams }: { searchParams: { rubrique?: string } }) {
  const s = await getSettings();
  const r = RUBRIQUES.find((x) => x.id === searchParams.rubrique) ?? RUBRIQUES[0];

  return (
    <main>
      <header className="wrap" style={{ paddingTop: 24 }}><Header /></header>
      <section className="wrap-etroit" style={{ paddingTop: 56 }}>
        <div className="fil"><Link href="/">Accueil</Link> · <span>{r.label}</span></div>
        <h1 className="aide-titre">{r.label}</h1>
      </section>

      <section className="wrap-etroit" style={{ paddingTop: 40, paddingBottom: 40 }}>
        <div className="aide">
          <nav className="aide__menu" aria-label="Rubriques d’aide">
            {RUBRIQUES.map((x) => (
              <Link key={x.id} href={'/aide?rubrique=' + x.id} aria-current={x.id === r.id ? 'page' : undefined} className="aide__onglet" scroll={false}>{x.label}</Link>
            ))}
          </nav>

          <div className="aide__contenu">
            {r.id === 'livraison' && (
              <div>
                <div className="aide__chiffres">
                  <div><strong>{s.shippingDelay}</strong><span>partout en Tunisie</span></div>
                  <div><strong>{s.shippingFee} DT</strong><span>frais de livraison{s.freeShippingFrom ? ` · offerte dès ${s.freeShippingFrom} DT` : ''}</span></div>
                  <div><strong>À la livraison</strong><span>paiement en espèces</span></div>
                </div>
                <h2 className="aide__h">La livraison</h2>
                <p className="aide__p">Nous livrons dans les 24 gouvernorats, en {s.shippingDelay} après la confirmation de votre commande. Les frais de livraison sont de {s.shippingFee} DT.</p>
                <p className="aide__p">Chaque pièce arrive dans sa pochette en coton écru, nouée d’un lien en lin : prête à offrir.</p>
                <h2 className="aide__h">Le paiement</h2>
                <p className="aide__p">Vous réglez en espèces, directement au livreur, à la réception de votre colis.</p>
              </div>
            )}

            {r.id === 'echanges' && (
              <div>
                <p className="aide__p">La taille ne convient pas ? Nous voulons que chaque pièce soit portée et aimée.</p>
                <h2 className="aide__h">Comment échanger</h2>
                <ol style={{ margin: '0 0 16px', paddingLeft: 22, fontSize: 16, lineHeight: 1.9 }}>
                  <li>Écrivez-nous sur WhatsApp au {s.whatsapp} avec votre numéro de commande.</li>
                  <li>[Délai pour demander l’échange : à définir]</li>
                  <li>[Conditions : pièce non portée, étiquette… à définir]</li>
                  <li>[Frais de l’échange : à définir]</li>
                </ol>
              </div>
            )}

            {r.id === 'tailles' && (
              <div>
                <p className="aide__p">Nos pièces vont de 2 à 6 ans. Mesures en centimètres ; entre deux tailles, nous conseillons la plus grande.</p>
                <div style={{ marginTop: 20 }}><SizeTable /></div>
                <h2 className="aide__h">Entretien</h2>
                <p className="aide__p" style={{ color: 'var(--texte-doux)' }}>[Conseils d’entretien du coton et du lin à fournir.]</p>
              </div>
            )}

            {r.id === 'contact' && (
              <div>
                <p className="aide__p">Une question sur une taille, une matière, une commande ? Nous vous répondons avec plaisir.</p>
                <div className="aide__contacts">
                  <a href={whatsappLink(s)} target="_blank" rel="noopener" style={{ background: 'var(--titre)', color: '#fff' }}>
                    <span className="aide__contact-label" style={{ opacity: .85 }}>WhatsApp</span>
                    <span style={{ fontSize: 22, fontWeight: 500 }}>{s.whatsapp}</span>
                    <span style={{ fontSize: 14, opacity: .85 }}>Le plus rapide</span>
                  </a>
                  <a href={instagramLink(s)} target="_blank" rel="noopener" style={{ background: 'var(--ecru)' }}>
                    <span className="aide__contact-label" style={{ color: 'var(--or)' }}>Instagram</span>
                    <span style={{ fontSize: 22, fontWeight: 500, color: 'var(--espresso)' }}>@{s.instagram}</span>
                    <span style={{ fontSize: 14, color: 'var(--texte-doux)' }}>Par message privé</span>
                  </a>
                </div>
                <h2 className="aide__h" style={{ marginTop: 0 }}>Ou laissez-nous un message</h2>
                <ContactForm />
              </div>
            )}

            {r.id === 'cgv' && (
              <div>
                <p className="aide__p" style={{ color: 'var(--texte-doux)' }}>Dernière mise à jour : [date]</p>
                <h2 className="aide__h">1. Vendeur</h2>
                <p className="aide__p">selima — selimaclothing.com. [Raison sociale, adresse, matricule fiscal à fournir.]</p>
                <h2 className="aide__h">2. Commandes</h2>
                <p className="aide__p">[Conditions de commande à rédiger.]</p>
                <h2 className="aide__h">3. Prix et paiement</h2>
                <p className="aide__p">Les prix sont indiqués en dinars tunisiens. Le paiement se fait à la livraison.</p>
                <h2 className="aide__h">4. Livraison</h2>
                <p className="aide__p">Livraison en {s.shippingDelay} partout en Tunisie, pour {s.shippingFee} DT.</p>
                <h2 className="aide__h">5. Échanges</h2>
                <p className="aide__p">[À rédiger.]</p>
                <h2 className="aide__h">6. Données personnelles</h2>
                <p className="aide__p">[À rédiger.]</p>
              </div>
            )}
          </div>
        </div>
      </section>
    </main>
  );
}
