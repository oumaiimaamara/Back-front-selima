import type { Metadata } from 'next';
import Link from 'next/link';
import Header from '@/components/Header';
import { FlecheGras } from '@/components/icons';

export const metadata: Metadata = { title: 'Nos matières', description: 'Coton et lin : le luxe commence par la matière.' };

const COULEURS = [
  { nom: 'Blanc coton', hex: '#FFFFFF' },
  { nom: 'Écru', hex: '#F2EEE5' },
  { nom: 'Rose poudré', hex: '#E2C6CC' },
  { nom: 'Camel', hex: '#C4A98F' },
  { nom: 'Kaki lin', hex: '#A58B5E' },
  { nom: 'Prune fleurie', hex: '#8D505A' },
  { nom: 'Espresso', hex: '#3D1E12' },
];

const MATIERES = [
  { img: '/images/indice-matieres.jpg', alt: 'Coton blanc en gros plan', nom: 'Le coton', sous: 'Respirant · doux', txt: 'Hypoallergénique, il respecte les peaux les plus délicates. Pour la blouse et la robe fleurie.' },
  { img: '/images/indice-age.jpg', alt: 'Pantalon en lin porté', nom: 'Le lin', sous: 'Souple · durable', txt: 'Solide et léger, il suit chaque mouvement, saison après saison. Pour le pantalon du set.', pos: '50% 70%' },
  { img: '/images/indice-details.jpg', alt: 'Lien noué dans le dos d’une blouse', nom: 'Les finitions', sous: 'Cousu avec soin', txt: 'Liens noués, fronces, col volanté, boutons au dos : rien n’est laissé au hasard.' },
];

export default function NosMatieres() {
  return (
    <main>
      <header className="wrap" style={{ paddingTop: 24 }}><Header /></header>
      <div className="wrap-etroit" style={{ paddingTop: 56 }}>
        <p className="sep">Nos matières</p>
        <section className="mat-tete">
          <img src="/images/logo-selima.png" alt="Iris selima" />
          <h1>Coton &amp; lin</h1>
          <p>Le luxe commence par la matière</p>
        </section>

        <p className="sep" style={{ marginTop: 72 }}>Ce que nous choisissons</p>
        <section className="mat-trio">
          {MATIERES.map((m, i) => (
            <div key={m.nom} style={{ display: 'contents' }}>
              {i > 0 && <span className="mat-trait" />}
              <div>
                <div className="mat-rond"><img src={m.img} alt={m.alt} style={{ objectPosition: m.pos }} /></div>
                <h2 className="mat-nom">{m.nom}</h2>
                <p className="mat-sous">{m.sous}</p>
                <p className="mat-txt">{m.txt}</p>
              </div>
            </div>
          ))}
        </section>

        <p className="sep" style={{ marginTop: 88 }}>Nos couleurs</p>
        <section className="mat-palette">
          {COULEURS.map((c) => (
            <div key={c.nom}>
              <span style={{ background: c.hex, boxShadow: c.hex === '#FFFFFF' ? 'inset 0 0 0 1px var(--contour)' : undefined }} />
              <strong>{c.nom}</strong>
              <em>{c.hex}</em>
            </div>
          ))}
        </section>

        <p className="sep" style={{ marginTop: 88 }}>Au toucher</p>
        <section className="mat-duo">
          <div>
            <div className="mat-cent">100 %</div>
            <div className="mat-fibre">Coton</div>
            <div className="mat-qualites">RESPIRANT · DOUX · HYPOALLERGÉNIQUE<br /><span>La blouse blanche du set · la robe fleurie, doublée</span></div>
          </div>
          <div>
            <div className="mat-cent">100 %</div>
            <div className="mat-fibre">Lin</div>
            <div className="mat-qualites">SOUPLE · SOLIDE · DURABLE<br /><span>Le pantalon kaki du set, poches plaquées et revers</span></div>
          </div>
        </section>

        <p className="sep" style={{ marginTop: 88 }}>L’univers selima</p>
        <section className="mat-mood">
          <div style={{ background: '#E2C6CC' }} />
          <div><img src="/images/robe-fleurie.jpg" alt="La robe fleurie portée et sur mannequin, de dos" /></div>
          <div style={{ background: '#A58B5E' }} />
          <div><img src="/images/indice-couleurs.jpg" alt="Blouse blanche et pantalon kaki" /></div>
          <div><img src="/images/curieux.jpg" alt="Détail d’une blouse en coton" /></div>
          <div style={{ background: '#C4A98F' }} />
          <div><img src="/images/slide-1.jpg" alt="Petite fille de dos en tenue selima" style={{ objectPosition: '50% 30%' }} /></div>
          <div style={{ background: '#8D505A' }} />
        </section>

        <div style={{ marginTop: 64, display: 'flex', justifyContent: 'center' }}>
          <Link href="/boutique" className="bouton" style={{ border: '1.5px solid var(--texte)' }}>
            Découvrir la collection
            <span className="rond-rose" style={{ width: 44, height: 44 }}><FlecheGras size={16} /></span>
          </Link>
        </div>
      </div>
    </main>
  );
}
