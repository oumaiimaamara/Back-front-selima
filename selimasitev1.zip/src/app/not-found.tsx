import Link from 'next/link';

export default function NotFound() {
  return (
    <main style={{ minHeight: '70vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, padding: 24, textAlign: 'center' }}>
      <img src="/images/logo-selima.png" alt="" style={{ width: 80, height: 80, borderRadius: '50%' }} />
      <p style={{ margin: 0, fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 36, color: 'var(--titre)' }}>Cette page s’est cachée…</p>
      <Link href="/" className="bouton-plein" style={{ height: 56, fontSize: 15 }}>Retour à l’accueil</Link>
    </main>
  );
}
