import { db, schema } from '@/db';

export type FaqItem = { q: string; a: string };

export type SiteSettings = {
  shopName: string;
  contactEmail: string;
  whatsapp: string; // format affiché : « 56 614 914 »
  instagram: string; // sans @
  shippingFee: number;
  shippingDelay: string;
  freeShippingFrom: number | null;
  lowStockThreshold: number;
  announcement: string;
  hero: { kicker: string; title: string; text: string; buttonLabel: string; buttonHref: string };
  homeBlocks: { categories: boolean; collection: boolean; materials: boolean; gift: boolean; faq: boolean; instagram: boolean; commitments: boolean };
  faq: FaqItem[];
};

export const DEFAULT_SETTINGS: SiteSettings = {
  shopName: 'selima',
  contactEmail: '',
  whatsapp: '56 614 914',
  instagram: '2s_selima',
  shippingFee: 8,
  shippingDelay: '24–48 h',
  freeShippingFrom: null,
  lowStockThreshold: 5,
  announcement: 'Livraison 24–48 h partout en Tunisie · 8 DT · Paiement à la livraison',
  hero: {
    kicker: 'Nouvelle collection · Automne',
    title: 'L’enfance, avec élégance',
    text: 'Coton et lin pour les petites filles de 2 à 6 ans, cousus avec soin en Tunisie.',
    buttonLabel: 'Découvrir la collection',
    buttonHref: '/boutique',
  },
  homeBlocks: { categories: true, collection: true, materials: true, gift: true, faq: true, instagram: true, commitments: true },
  faq: [
    { q: 'Comment choisir la bonne taille ?', a: 'Nos tailles vont de 2 à 6 ans. Le guide des tailles donne les mesures de chaque pièce, et nous vous conseillons volontiers sur WhatsApp.' },
    { q: 'Combien de temps pour la livraison ?', a: '24 à 48 h partout en Tunisie, pour 8 DT.' },
    { q: 'Comment se passe le paiement ?', a: 'Vous payez à la livraison, directement au livreur.' },
    { q: 'Comment entretenir le coton et le lin ?', a: '[Conseils d’entretien à fournir : température de lavage, séchage, repassage.]' },
    { q: 'Puis-je échanger une taille ?', a: '[Politique d’échange à définir : délai, conditions, frais.]' },
  ],
};

export async function getSettings(): Promise<SiteSettings> {
  try {
    const rows = await db.select().from(schema.settings);
    const stored = Object.fromEntries(rows.map((r) => [r.key, r.value]));
    return { ...DEFAULT_SETTINGS, ...stored } as SiteSettings;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export async function saveSettings(partial: Partial<SiteSettings>) {
  for (const [key, value] of Object.entries(partial)) {
    await db
      .insert(schema.settings)
      .values({ key, value: value as unknown })
      .onConflictDoUpdate({ target: schema.settings.key, set: { value: value as unknown } });
  }
}

export function whatsappLink(settings: SiteSettings, text?: string) {
  const digits = settings.whatsapp.replace(/\D/g, '');
  const intl = digits.startsWith('216') ? digits : '216' + digits;
  return 'https://wa.me/' + intl + (text ? '?text=' + encodeURIComponent(text) : '');
}

export function instagramLink(settings: SiteSettings) {
  return 'https://www.instagram.com/' + settings.instagram.replace(/^@/, '');
}
