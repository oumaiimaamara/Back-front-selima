import { and, asc, eq, inArray } from 'drizzle-orm';
import { db, schema } from '@/db';

import { type ProductCardData, type ProductDetail } from './catalog-types';
export * from './catalog-types';

export async function getCategories(onlyVisible = true) {
  const rows = await db.select().from(schema.categories).orderBy(asc(schema.categories.position));
  return onlyVisible ? rows.filter((c) => c.visible) : rows;
}

export async function getSlides() {
  return db.select().from(schema.slides).orderBy(asc(schema.slides.position));
}

async function hydrate(products: (typeof schema.products.$inferSelect)[], threshold: number): Promise<ProductCardData[]> {
  if (!products.length) return [];
  const ids = products.map((p) => p.id);
  const [images, sizes] = await Promise.all([
    db.select().from(schema.productImages).where(inArray(schema.productImages.productId, ids)).orderBy(asc(schema.productImages.position)),
    db.select().from(schema.productSizes).where(inArray(schema.productSizes.productId, ids)).orderBy(asc(schema.productSizes.position)),
  ]);
  return products.map((p) => {
    const img = images.find((i) => i.productId === p.id);
    const sz = sizes.filter((s) => s.productId === p.id).map((s) => ({ size: s.size, stock: s.stock }));
    const available = sz.filter((s) => s.stock > 0);
    return {
      id: p.id, slug: p.slug, name: p.name, subtitle: p.subtitle, price: p.price, comparePrice: p.comparePrice,
      label: p.label, image: img?.url ?? null, imageAlt: img?.alt ?? p.name,
      colors: p.colors, materials: p.materials, sizes: sz,
      lowStock: available.some((s) => s.stock < threshold),
      soldOut: sz.length > 0 && available.length === 0,
    };
  });
}

export async function getProducts(opts: { category?: string; size?: string; material?: string; sort?: string; threshold: number }) {
  let ids: number[] | null = null;
  if (opts.category) {
    const cat = await db.select().from(schema.categories).where(eq(schema.categories.slug, opts.category)).limit(1);
    if (!cat.length) return [];
    const links = await db.select().from(schema.productCategories).where(eq(schema.productCategories.categoryId, cat[0].id));
    ids = links.map((l) => l.productId);
    if (!ids.length) return [];
  }
  const rows = await db.select().from(schema.products)
    .where(ids ? and(eq(schema.products.published, true), inArray(schema.products.id, ids)) : eq(schema.products.published, true))
    .orderBy(asc(schema.products.position), asc(schema.products.id));
  let list = await hydrate(rows, opts.threshold);
  if (opts.size) list = list.filter((p) => p.sizes.some((s) => s.size === opts.size && s.stock > 0));
  if (opts.material) list = list.filter((p) => p.materials.includes(opts.material!));
  if (opts.sort === 'prix-asc') list.sort((a, b) => a.price - b.price);
  if (opts.sort === 'prix-desc') list.sort((a, b) => b.price - a.price);
  return list;
}

export async function getProductBySlug(slug: string, threshold: number): Promise<ProductDetail | null> {
  const rows = await db.select().from(schema.products).where(and(eq(schema.products.slug, slug), eq(schema.products.published, true))).limit(1);
  if (!rows.length) return null;
  const p = rows[0];
  const [card] = await hydrate([p], threshold);
  const images = await db.select().from(schema.productImages).where(eq(schema.productImages.productId, p.id)).orderBy(asc(schema.productImages.position));
  return {
    ...card,
    description: p.description,
    details: p.details.split('\n').map((l) => l.trim()).filter(Boolean),
    care: p.care,
    images: images.map((i) => ({ url: i.url, alt: i.alt })),
  };
}

export async function getOtherProducts(excludeId: number, threshold: number, limit = 3) {
  const all = await getProducts({ threshold });
  return all.filter((p) => p.id !== excludeId).slice(0, limit);
}

