'use server';

import { and, eq, gte, inArray, sql } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '@/db';
import { GOVERNORATES } from './catalog-types';
import { getSettings } from './settings';

const commandeSchema = z.object({
  items: z.array(z.object({
    productId: z.number().int().positive(),
    size: z.string().min(1).max(20),
    quantity: z.number().int().min(1).max(10),
  })).min(1, 'Votre panier est vide.').max(30),
  firstName: z.string().trim().min(1, 'Indiquez votre prénom.').max(60),
  lastName: z.string().trim().min(1, 'Indiquez votre nom.').max(60),
  phone: z.string().trim().regex(/^(\+?216)?\s?[2-9]\d(\s?\d){6}$/, 'Numéro de téléphone tunisien invalide (8 chiffres).'),
  email: z.string().trim().email('Adresse e-mail invalide.').max(120).optional().or(z.literal('')),
  address: z.string().trim().min(5, 'Indiquez votre adresse.').max(200),
  governorate: z.enum(GOVERNORATES as [string, ...string[]], { errorMap: () => ({ message: 'Choisissez votre gouvernorat.' }) }),
  city: z.string().trim().min(2, 'Indiquez votre ville.').max(80),
  note: z.string().trim().max(500).optional(),
});

export type CommandeInput = z.infer<typeof commandeSchema>;
export type CommandeResult =
  | { ok: true; number: string }
  | { ok: false; error: string; fields?: Record<string, string> };

class StockError extends Error {}

export async function passerCommande(input: CommandeInput): Promise<CommandeResult> {
  const parsed = commandeSchema.safeParse(input);
  if (!parsed.success) {
    const fields: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const k = String(issue.path[0]);
      if (!fields[k]) fields[k] = issue.message;
    }
    return { ok: false, error: 'Merci de vérifier les informations en rouge.', fields };
  }
  const data = parsed.data;
  const settings = await getSettings();

  try {
    const number = await db.transaction(async (tx) => {
      const ids = Array.from(new Set(data.items.map((i) => i.productId)));
      const prods = await tx.select().from(schema.products).where(and(inArray(schema.products.id, ids), eq(schema.products.published, true)));
      const lignes = data.items.map((it) => {
        const p = prods.find((x) => x.id === it.productId);
        if (!p) throw new StockError('Une pièce de votre panier n’est plus disponible.');
        return { ...it, name: p.name, price: p.price };
      });

      // Réserver le stock : la mise à jour échoue si la quantité n’est plus disponible.
      for (const l of lignes) {
        const res = await tx.update(schema.productSizes)
          .set({ stock: sql`${schema.productSizes.stock} - ${l.quantity}` })
          .where(and(eq(schema.productSizes.productId, l.productId), eq(schema.productSizes.size, l.size), gte(schema.productSizes.stock, l.quantity)))
          .returning({ id: schema.productSizes.id });
        if (!res.length) throw new StockError(`« ${l.name} » en ${l.size} n’est plus disponible dans cette quantité.`);
      }

      const subtotal = lignes.reduce((t, l) => t + l.price * l.quantity, 0);
      const shipping = settings.freeShippingFrom && subtotal >= settings.freeShippingFrom ? 0 : settings.shippingFee;

      const [order] = await tx.insert(schema.orders).values({
        number: 'tmp-' + Date.now() + Math.random(),
        firstName: data.firstName, lastName: data.lastName, phone: data.phone,
        email: data.email || null, address: data.address, city: data.city, governorate: data.governorate,
        note: data.note || null, subtotal, shipping, total: subtotal + shipping,
      }).returning({ id: schema.orders.id });

      const num = 'SL-' + String(order.id).padStart(4, '0');
      await tx.update(schema.orders).set({ number: num }).where(eq(schema.orders.id, order.id));
      await tx.insert(schema.orderItems).values(lignes.map((l) => ({
        orderId: order.id, productId: l.productId, productName: l.name, size: l.size, unitPrice: l.price, quantity: l.quantity,
      })));
      return num;
    });
    return { ok: true, number };
  } catch (e) {
    if (e instanceof StockError) return { ok: false, error: e.message };
    console.error(e);
    return { ok: false, error: 'Un problème est survenu. Réessayez, ou écrivez-nous sur WhatsApp.' };
  }
}

const messageSchema = z.object({
  name: z.string().trim().min(1, 'Indiquez votre nom.').max(80),
  phone: z.string().trim().min(8, 'Indiquez votre téléphone.').max(20),
  body: z.string().trim().min(3, 'Écrivez votre message.').max(2000),
});

export async function envoyerMessage(input: z.infer<typeof messageSchema>): Promise<{ ok: boolean; error?: string }> {
  const parsed = messageSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message };
  await db.insert(schema.messages).values(parsed.data);
  return { ok: true };
}
