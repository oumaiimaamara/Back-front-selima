export type ProductCardData = {
  id: number;
  slug: string;
  name: string;
  subtitle: string;
  price: number;
  comparePrice: number | null;
  label: 'aucune' | 'nouveau' | 'edition_limitee';
  image: string | null;
  imageAlt: string;
  colors: { name: string; hex: string }[];
  materials: string[];
  sizes: { size: string; stock: number }[];
  lowStock: boolean;
  soldOut: boolean;
};

export type ProductDetail = ProductCardData & {
  description: string;
  details: string[];
  care: string;
  images: { url: string; alt: string }[];
};

export const LABELS: Record<ProductCardData['label'], string> = {
  aucune: '',
  nouveau: 'Nouveau',
  edition_limitee: 'Édition limitée',
};

export const SIZES = ['2 ans', '3 ans', '4 ans', '5 ans', '6 ans'];
export const GOVERNORATES = ['Ariana', 'Béja', 'Ben Arous', 'Bizerte', 'Gabès', 'Gafsa', 'Jendouba', 'Kairouan', 'Kasserine', 'Kébili', 'Le Kef', 'Mahdia', 'La Manouba', 'Médenine', 'Monastir', 'Nabeul', 'Sfax', 'Sidi Bouzid', 'Siliana', 'Sousse', 'Tataouine', 'Tozeur', 'Tunis', 'Zaghouan'];
