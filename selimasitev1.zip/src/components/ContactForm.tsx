'use client';

import { useState, useTransition } from 'react';
import { envoyerMessage } from '@/lib/actions';

export default function ContactForm() {
  const [pending, start] = useTransition();
  const [envoye, setEnvoye] = useState(false);
  const [erreur, setErreur] = useState('');

  if (envoye) {
    return <div role="status" style={{ borderRadius: 20, background: 'var(--carte-qualite)', padding: '20px 24px', fontSize: 15 }}>Merci ! Votre message est bien envoyé, nous vous répondons très vite.</div>;
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        start(async () => {
          const res = await envoyerMessage({ name: String(f.get('name') ?? ''), phone: String(f.get('phone') ?? ''), body: String(f.get('body') ?? '') });
          if (res.ok) setEnvoye(true); else setErreur(res.error ?? 'Erreur');
        });
      }}
      style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 620 }}
    >
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
        <label className="champ" style={{ flex: '1 1 240px' }}>Nom<input name="name" autoComplete="name" required /></label>
        <label className="champ" style={{ flex: '1 1 240px' }}>Téléphone<input name="phone" type="tel" autoComplete="tel" placeholder="2X XXX XXX" required /></label>
      </div>
      <label className="champ">Message<textarea name="body" style={{ height: 130 }} required /></label>
      {erreur && <p className="erreur" role="alert">{erreur}</p>}
      <button type="submit" className="bouton-plein" style={{ alignSelf: 'flex-start', height: 56, fontSize: 15 }} disabled={pending}>{pending ? 'Envoi…' : 'Envoyer'}</button>
    </form>
  );
}
