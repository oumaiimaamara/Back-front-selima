import Link from 'next/link';
import { instagramLink, whatsappLink, type SiteSettings } from '@/lib/settings';
import { Bulle } from './icons';

export default function Footer({ settings, products }: { settings: SiteSettings; products: { slug: string; name: string }[] }) {
  return (
    <>
      <footer className="wrap pied">
        <div className="pied__grille">
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, fontSize: 20, fontWeight: 600, color: 'var(--titre)' }}>
              <img src="/images/logo-selima.png" alt="" style={{ width: 52, height: 52, borderRadius: '50%' }} />selima
            </div>
            <p style={{ margin: '16px 0 0', fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 22, color: 'var(--titre)' }}>L’enfance, avec élégance</p>
            <p style={{ margin: '8px 0 0', fontSize: 14, lineHeight: 1.6, color: 'var(--texte-doux)', maxWidth: 320 }}>Vêtements pour filles de 2 à 6 ans, en coton et en lin. Made in Tunisia.</p>
          </div>
          <div className="pied__col">
            <strong>Boutique</strong>
            {products.map((p) => <Link key={p.slug} href={'/produit/' + p.slug}>{p.name}</Link>)}
            <Link href="/aide?rubrique=tailles">Guide des tailles</Link>
          </div>
          <div className="pied__col">
            <strong>Aide</strong>
            <Link href="/aide?rubrique=livraison">Livraison &amp; paiement</Link>
            <Link href="/aide?rubrique=echanges">Échanges</Link>
            <Link href="/aide?rubrique=cgv">Conditions de vente</Link>
          </div>
          <div className="pied__col">
            <strong>Contact</strong>
            <a href={whatsappLink(settings)} target="_blank" rel="noopener">WhatsApp {settings.whatsapp}</a>
            <a href={instagramLink(settings)} target="_blank" rel="noopener">Instagram @{settings.instagram}</a>
            <Link href="/aide?rubrique=contact">Nous écrire</Link>
          </div>
        </div>
        <div className="pied__bas">
          <span>© {new Date().getFullYear()} selima · selimaclothing.com</span>
          <span>Cousu avec soin en Tunisie</span>
        </div>
      </footer>
      <a href={whatsappLink(settings, 'Bonjour selima !')} target="_blank" rel="noopener" className="whatsapp-flottant" aria-label="Nous écrire sur WhatsApp">
        <Bulle size={26} />
      </a>
    </>
  );
}
