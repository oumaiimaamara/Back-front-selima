'use client';

import { useEffect, useState } from 'react';

export default function HeroSlider({ slides }: { slides: { url: string; alt: string }[] }) {
  const [i, setI] = useState(0);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (slides.length < 2) return;
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const t = setInterval(() => setI((n) => (n + 1) % slides.length), 5000);
    return () => clearInterval(t);
  }, [slides.length, tick]);

  return (
    <>
      {slides.map((s, n) => (
        <img key={s.url + n} src={s.url} alt={n === i ? s.alt : ''} className={'hero__slide' + (n === i ? ' actif' : '')} />
      ))}
      <div className="hero__voile" />
      {slides.length > 1 && (
        <div className="points" role="group" aria-label="Choisir une photo">
          {slides.map((_, n) => (
            <button key={n} type="button" aria-label={'Photo ' + (n + 1)} aria-current={n === i} onClick={() => { setI(n); setTick((t) => t + 1); }} />
          ))}
        </div>
      )}
    </>
  );
}
