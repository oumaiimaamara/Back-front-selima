'use client';

import { usePathname, useRouter, useSearchParams } from 'next/navigation';

export default function SortSelect({ value }: { value: string }) {
  const router = useRouter();
  const path = usePathname();
  const params = useSearchParams();
  return (
    <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, fontWeight: 500 }}>
      Trier par
      <select
        value={value}
        onChange={(e) => {
          const p = new URLSearchParams(params.toString());
          if (e.target.value) p.set('tri', e.target.value); else p.delete('tri');
          router.push(path + (p.toString() ? '?' + p.toString() : ''), { scroll: false });
        }}
        style={{ height: 44, borderRadius: 999, border: '1.5px solid var(--texte)', background: '#fff', padding: '0 16px', fontSize: 14, color: 'var(--texte)' }}
      >
        <option value="">Nouveautés</option>
        <option value="prix-asc">Prix croissant</option>
        <option value="prix-desc">Prix décroissant</option>
      </select>
    </label>
  );
}
