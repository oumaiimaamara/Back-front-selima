'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useCart } from './cart';
import { Compte, Loupe } from './icons';

const LIENS = [
  { href: '/boutique', label: 'La boutique' },
  { href: '/nos-matieres', label: 'Nos matières' },
  { href: '/#curieux', label: 'Pour les curieux' },
  { href: '/aide?rubrique=tailles', label: 'Guide des tailles' },
];

export default function Header({ variant = 'blanc' }: { variant?: 'blanc' | 'photo' }) {
  const path = usePathname();
  const { count, ready } = useCart();
  return (
    <nav className={'nav' + (variant === 'photo' ? ' nav--photo' : '')} aria-label="Navigation principale">
      <div className="nav__pilule">
        <Link href="/" className="nav__marque">
          <img src="/images/logo-selima.png" alt="" />selima
        </Link>
        <div className="nav__liens">
          {LIENS.map((l) => (
            <Link key={l.href} href={l.href} aria-current={path.startsWith(l.href.split('?')[0]) && l.href !== '/#curieux' && path !== '/' ? 'page' : undefined}>
              {l.label}
            </Link>
          ))}
        </div>
      </div>
      <div className="nav__actions">
        <Link href="/boutique" className="rond-icone" aria-label="Voir la boutique"><Loupe /></Link>
        <Link href="/admin" className="rond-icone" aria-label="Espace de gestion"><Compte /></Link>
        <Link href="/panier" className="panier-bt">
          <span className="panier-bt__txt">Mon panier</span>
          <span className="panier-bt__n" aria-label={(ready ? count : 0) + ' article(s)'}>{ready ? count : 0}</span>
        </Link>
      </div>
    </nav>
  );
}
