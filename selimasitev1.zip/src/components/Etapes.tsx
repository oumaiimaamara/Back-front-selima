'use client';

import { usePathname } from 'next/navigation';

const ETAPES = ['Panier', 'Livraison', 'Confirmation'];

export default function Etapes() {
  const path = usePathname();
  const idx = path.startsWith('/commande/merci') ? 2 : path.startsWith('/commande') ? 1 : 0;
  return (
    <ol aria-label="Étapes de la commande" style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', alignItems: 'center', gap: 10 }}>
      {ETAPES.map((label, i) => {
        const fait = i < idx, actif = i === idx;
        return (
          <li key={label} style={{ display: 'flex', alignItems: 'center', gap: 10 }} aria-current={actif ? 'step' : undefined}>
            <span style={{
              width: 30, height: 30, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 600,
              ...(actif || fait ? { background: 'var(--titre)', color: '#fff' } : { background: '#fff', color: 'var(--texte-doux)', boxShadow: 'inset 0 0 0 1.5px var(--contour)' }),
            }}>{fait ? '✓' : i + 1}</span>
            <span className="achat-masque" style={{ fontSize: 14, fontWeight: actif ? 600 : 500, color: actif ? 'var(--titre)' : 'var(--texte-doux)' }}>{label}</span>
            {i < 2 && <span style={{ width: 32, height: 1.5, background: 'var(--contour)' }} />}
          </li>
        );
      })}
    </ol>
  );
}
