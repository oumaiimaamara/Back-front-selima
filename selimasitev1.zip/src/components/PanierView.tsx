'use client';

import Link from 'next/link';
import { useCart } from './cart';

export function fraisLivraison(subtotal: number, fee: number, freeFrom: number | null) {
  return freeFrom && subtotal >= freeFrom ? 0 : fee;
}

export default function PanierView({ shippingFee, freeFrom, shippingDelay }: { shippingFee: number; freeFrom: number | null; shippingDelay: string }) {
  const { items, ready, subtotal, setQuantity, remove } = useCart();
  const livraison = fraisLivraison(subtotal, shippingFee, freeFrom);

  return (
    <main className="wrap-etroit" style={{ paddingTop: 56, paddingBottom: 96 }}>
      <h1 className="achat-titre">Mon panier</h1>

      {ready && items.length === 0 && (
        <div className="panier-vide">
          <img src="/images/logo-selima.png" alt="" />
          <p className="panier-vide__titre">Votre panier est vide</p>
          <p style={{ margin: '8px 0 24px', fontSize: 15, color: 'var(--texte-doux)' }}>Nos pièces en coton et en lin vous attendent.</p>
          <Link href="/boutique" className="bouton-plein" style={{ height: 56, fontSize: 15 }}>Découvrir la boutique</Link>
        </div>
      )}

      {ready && items.length > 0 && (
        <div className="achat-cols" style={{ marginTop: 32 }}>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {items.map((a) => (
              <div key={a.productId + a.size} className="ligne-panier">
                <Link href={'/produit/' + a.slug} className="ligne-panier__photo">{a.image && <img src={a.image} alt="" />}</Link>
                <div style={{ minWidth: 0 }}>
                  <Link href={'/produit/' + a.slug} style={{ fontSize: 17, fontWeight: 500 }}>{a.name}</Link>
                  <div style={{ marginTop: 4, fontSize: 14, color: 'var(--texte-doux)' }}>Taille {a.size}</div>
                  <div style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
                    <div className="quantite" style={{ height: 44, padding: '0 4px' }}>
                      <button type="button" style={{ width: 36, height: 36, fontSize: 18 }} onClick={() => setQuantity(a.productId, a.size, a.quantity - 1)} aria-label="Diminuer">−</button>
                      <span>{a.quantity}</span>
                      <button type="button" style={{ width: 36, height: 36, fontSize: 18 }} onClick={() => setQuantity(a.productId, a.size, a.quantity + 1)} aria-label="Augmenter">+</button>
                    </div>
                    <button type="button" className="lien" style={{ color: 'var(--texte-doux)' }} onClick={() => remove(a.productId, a.size)}>Retirer</button>
                  </div>
                </div>
                <div className="ligne-panier__prix">{a.price * a.quantity} DT</div>
              </div>
            ))}
            <Link href="/boutique" className="lien" style={{ marginTop: 22 }}>← Continuer mes achats</Link>
          </div>

          <aside className="recap">
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 500, color: 'var(--titre)' }}>Récapitulatif</h2>
            <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 12, fontSize: 15 }}>
              <div className="recap__ligne"><span>Sous-total</span><span>{subtotal} DT</span></div>
              <div className="recap__ligne"><span>Livraison ({shippingDelay})</span><span>{livraison ? livraison + ' DT' : 'Offerte'}</span></div>
            </div>
            <div className="recap__total"><span style={{ fontSize: 16, fontWeight: 600 }}>Total</span><span style={{ fontSize: 26, fontWeight: 600 }}>{subtotal + livraison} DT</span></div>
            <Link href="/commande" className="bouton-plein" style={{ marginTop: 24, width: '100%' }}>Passer la commande</Link>
            <div style={{ marginTop: 20, display: 'flex', flexDirection: 'column', gap: 10, fontSize: 13, color: 'var(--texte-doux)' }}>
              <span>· Paiement à la livraison</span>
              <span>· Livré dans sa pochette en coton écru</span>
            </div>
          </aside>
        </div>
      )}
    </main>
  );
}
