// Mesures à fournir par selima : remplacer « [à fournir] » par les valeurs réelles.
const LIGNES = ['2 ans', '3 ans', '4 ans', '5 ans', '6 ans'].map((age) => ({ age, hauteur: '[à fournir]', poitrine: '[à fournir]', pantalon: '[à fournir]' }));

export default function SizeTable() {
  return (
    <div style={{ overflowX: 'auto', borderRadius: 22, border: '1px solid var(--trait)' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 15, minWidth: 460 }}>
        <thead>
          <tr style={{ textAlign: 'left', background: 'var(--carte-qualite)', color: 'var(--titre)' }}>
            <th style={{ padding: '16px 20px' }}>Âge</th>
            <th style={{ padding: '16px 20px' }}>Hauteur</th>
            <th style={{ padding: '16px 20px' }}>Tour de poitrine</th>
            <th style={{ padding: '16px 20px' }}>Long. pantalon</th>
          </tr>
        </thead>
        <tbody>
          {LIGNES.map((l) => (
            <tr key={l.age}>
              <td style={{ padding: '16px 20px', borderTop: '1px solid var(--trait)', fontWeight: 600 }}>{l.age}</td>
              <td style={{ padding: '16px 20px', borderTop: '1px solid var(--trait)', color: 'var(--texte-doux)' }}>{l.hauteur}</td>
              <td style={{ padding: '16px 20px', borderTop: '1px solid var(--trait)', color: 'var(--texte-doux)' }}>{l.poitrine}</td>
              <td style={{ padding: '16px 20px', borderTop: '1px solid var(--trait)', color: 'var(--texte-doux)' }}>{l.pantalon}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
