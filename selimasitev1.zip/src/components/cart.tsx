'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

export type CartItem = {
  productId: number;
  slug: string;
  name: string;
  size: string;
  price: number;
  image: string | null;
  quantity: number;
};

type CartCtx = {
  items: CartItem[];
  ready: boolean;
  count: number;
  subtotal: number;
  add: (item: Omit<CartItem, 'quantity'>, quantity?: number) => void;
  setQuantity: (productId: number, size: string, quantity: number) => void;
  remove: (productId: number, size: string) => void;
  clear: () => void;
};

const Ctx = createContext<CartCtx | null>(null);
const KEY = 'selima-panier';
const MAX = 10;

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch {}
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try { localStorage.setItem(KEY, JSON.stringify(items)); } catch {}
  }, [items, ready]);

  const add = useCallback((item: Omit<CartItem, 'quantity'>, quantity = 1) => {
    setItems((list) => {
      const i = list.findIndex((x) => x.productId === item.productId && x.size === item.size);
      if (i >= 0) {
        const copy = list.slice();
        copy[i] = { ...copy[i], quantity: Math.min(MAX, copy[i].quantity + quantity) };
        return copy;
      }
      return list.concat({ ...item, quantity: Math.min(MAX, quantity) });
    });
  }, []);

  const setQuantity = useCallback((productId: number, size: string, quantity: number) => {
    setItems((list) => list
      .map((x) => (x.productId === productId && x.size === size ? { ...x, quantity: Math.min(MAX, quantity) } : x))
      .filter((x) => x.quantity > 0));
  }, []);

  const remove = useCallback((productId: number, size: string) => {
    setItems((list) => list.filter((x) => !(x.productId === productId && x.size === size)));
  }, []);

  const clear = useCallback(() => setItems([]), []);

  const value = useMemo(() => ({
    items, ready, add, setQuantity, remove, clear,
    count: items.reduce((t, x) => t + x.quantity, 0),
    subtotal: items.reduce((t, x) => t + x.quantity * x.price, 0),
  }), [items, ready, add, setQuantity, remove, clear]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useCart doit être utilisé dans CartProvider');
  return c;
}
