import Link from 'next/link';

type Cat = { slug: string; name: string; image: string | null };

export default function CategoryRow({ categories, current, small, showAll }: { categories: Cat[]; current?: string; small?: boolean; showAll?: boolean }) {
  return (
    <div className={'cats' + (small ? ' cats--petits' : '')}>
      {showAll && (
        <Link href="/boutique" className="cat" aria-current={!current ? 'page' : undefined}>
          <span className="cat__rond" style={{ background: 'var(--carte-qualite)' }}>
            <img src="/images/logo-selima.png" alt="" style={{ width: '70%', height: '70%', objectFit: 'contain' }} />
          </span>
          Tout voir
        </Link>
      )}
      {categories.map((c) => (
        <Link key={c.slug} href={'/boutique?categorie=' + c.slug} className="cat" aria-current={current === c.slug ? 'page' : undefined}>
          {c.image ? (
            <span className="cat__rond"><img src={c.image} alt="" /></span>
          ) : (
            <span className="cat__rond cat__rond--limitee"><span style={{ padding: '0 12px' }}>{c.name}</span></span>
          )}
          {c.name}
        </Link>
      ))}
    </div>
  );
}
