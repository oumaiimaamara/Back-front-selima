'use client';

import { useEffect } from 'react';
import SizeTable from './SizeTable';
import { Croix } from './icons';

export default function SizeGuidePanel({ onClose, whatsapp }: { onClose: () => void; whatsapp: string }) {
  useEffect(() => {
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', esc);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', esc); document.body.style.overflow = ''; };
  }, [onClose]);

  return (
    <div className="panneau-fond" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-label="Guide des tailles" className="panneau" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ margin: 0, fontSize: 30, fontWeight: 500, color: 'var(--titre)' }}>Guide des tailles</h2>
          <button type="button" onClick={onClose} aria-label="Fermer" className="rond-icone" style={{ width: 48, height: 48, cursor: 'pointer' }} autoFocus><Croix /></button>
        </div>
        <p style={{ margin: '14px 0 0', fontSize: 15, lineHeight: 1.6, color: 'var(--texte-doux)' }}>Mesures en centimètres. Entre deux tailles, nous conseillons la plus grande.</p>
        <div style={{ marginTop: 22 }}><SizeTable /></div>
        <div style={{ marginTop: 28, borderRadius: 20, background: 'var(--gris-rose)', padding: 20 }}>
          <p style={{ margin: 0, fontSize: 15, fontWeight: 500 }}>Toujours un doute ?</p>
          <p style={{ margin: '6px 0 14px', fontSize: 14, color: 'var(--texte-doux)' }}>Donnez-nous l’âge et la taille de votre petite fille, nous vous conseillons.</p>
          <a href={'https://wa.me/216' + whatsapp.replace(/\D/g, '')} target="_blank" rel="noopener" className="bouton-plein" style={{ height: 48, fontSize: 14, padding: '0 20px' }}>Écrire sur WhatsApp</a>
        </div>
      </div>
    </div>
  );
}
