'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState, useTransition } from 'react';
import { passerCommande } from '@/lib/actions';
import { GOVERNORATES } from '@/lib/catalog-types';
import { useCart } from './cart';
import { fraisLivraison } from './PanierView';

function Champ({ label, className = '', err, children }: { name?: string; label: string; className?: string; err?: string; children: React.ReactNode }) {
  return (
    <label className={'champ ' + className + (err ? ' champ--erreur' : '')}>
      {label}
      {children}
      {err && <span className="erreur">{err}</span>}
    </label>
  );
}

export default function CommandeForm({ shippingFee, freeFrom }: { shippingFee: number; freeFrom: number | null }) {
  const { items, ready, subtotal, clear } = useCart();
  const router = useRouter();
  const [pending, start] = useTransition();
  const [erreur, setErreur] = useState('');
  const [champs, setChamps] = useState<Record<string, string>>({});
  const livraison = fraisLivraison(subtotal, shippingFee, freeFrom);

  if (ready && items.length === 0) {
    return (
      <main className="wrap-etroit" style={{ paddingTop: 72, paddingBottom: 96, textAlign: 'center' }}>
        <p style={{ fontSize: 18 }}>Votre panier est vide.</p>
        <Link href="/boutique" className="bouton-plein" style={{ height: 56, fontSize: 15 }}>Découvrir la boutique</Link>
      </main>
    );
  }

  const envoyer = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const v = (k: string) => String(f.get(k) ?? '');
    setErreur('');
    start(async () => {
      const res = await passerCommande({
        items: items.map((i) => ({ productId: i.productId, size: i.size, quantity: i.quantity })),
        firstName: v('firstName'), lastName: v('lastName'), phone: v('phone'), email: v('email'),
        address: v('address'), governorate: v('governorate'), city: v('city'), note: v('note'),
      });
      if (res.ok) {
        clear();
        router.push('/commande/merci/' + res.number);
      } else {
        setErreur(res.error);
        setChamps(res.fields ?? {});
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  };

  return (
    <main className="wrap-etroit" style={{ paddingTop: 56, paddingBottom: 96 }}>
      <Link href="/panier" className="lien">← Retour au panier</Link>
      <h1 className="achat-titre" style={{ marginTop: 14 }}>Livraison</h1>
      <p style={{ margin: '8px 0 0', fontSize: 15, color: 'var(--texte-doux)' }}>Pas besoin de compte : quelques informations suffisent.</p>
      {erreur && <div role="alert" className="alerte-erreur">{erreur}</div>}

      <div className="achat-cols" style={{ marginTop: 32 }}>
        <form onSubmit={envoyer} noValidate style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
          <fieldset className="groupe">
            <legend>Vos coordonnées</legend>
            <div className="champs">
              <Champ name="firstName" err={champs.firstName} label="Prénom"><input name="firstName" autoComplete="given-name" required /></Champ>
              <Champ name="lastName" err={champs.lastName} label="Nom"><input name="lastName" autoComplete="family-name" required /></Champ>
              <Champ name="phone" err={champs.phone} label="Téléphone"><input name="phone" type="tel" autoComplete="tel" placeholder="2X XXX XXX" required /></Champ>
              <Champ name="email" err={champs.email} label="E-mail"><input name="email" type="email" autoComplete="email" placeholder="pour recevoir le récapitulatif" /></Champ>
            </div>
          </fieldset>

          <fieldset className="groupe">
            <legend>Adresse de livraison</legend>
            <div className="champs">
              <Champ name="address" err={champs.address} label="Adresse" className="plein"><input name="address" autoComplete="street-address" placeholder="Rue, numéro, immeuble, étage" required /></Champ>
              <Champ name="governorate" err={champs.governorate} label="Gouvernorat">
                <select name="governorate" defaultValue="" required>
                  <option value="" disabled>Choisir…</option>
                  {GOVERNORATES.map((g) => <option key={g}>{g}</option>)}
                </select>
              </Champ>
              <Champ name="city" err={champs.city} label="Ville"><input name="city" autoComplete="address-level2" required /></Champ>
              <Champ name="note" err={champs.note} label="Note pour le livreur (facultatif)" className="plein"><textarea name="note" placeholder="Horaires, point de repère…" /></Champ>
            </div>
          </fieldset>

          <fieldset className="groupe">
            <legend>Paiement</legend>
            <label className="choix-paiement">
              <input type="radio" name="paiement" defaultChecked />
              <span style={{ flex: 1 }}>
                <span style={{ display: 'block', fontSize: 15, fontWeight: 600 }}>Paiement à la livraison</span>
                <span style={{ display: 'block', marginTop: 2, fontSize: 14, color: 'var(--texte-doux)' }}>Vous réglez en espèces à la réception de votre colis.</span>
              </span>
            </label>
          </fieldset>

          <button type="submit" className="bouton-plein" disabled={pending || !ready}>
            {pending ? 'Envoi en cours…' : 'Confirmer la commande · ' + (subtotal + livraison) + ' DT'}
          </button>
        </form>

        <aside className="recap" style={{ padding: 28 }}>
          <h2 style={{ margin: 0, fontSize: 20, fontWeight: 500, color: 'var(--titre)' }}>Votre commande</h2>
          <div style={{ marginTop: 18, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {items.map((a) => (
              <div key={a.productId + a.size} style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
                <div style={{ position: 'relative', width: 64, height: 80, flexShrink: 0 }}>
                  <div style={{ width: 64, height: 80, borderRadius: 12, overflow: 'hidden', background: 'var(--trait)' }}>{a.image && <img src={a.image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}</div>
                  <span className="pastille-qte">{a.quantity}</span>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 15, fontWeight: 500 }}>{a.name}</div>
                  <div style={{ fontSize: 13, color: 'var(--texte-doux)' }}>Taille {a.size}</div>
                </div>
                <span style={{ fontSize: 15, fontWeight: 600 }}>{a.price * a.quantity} DT</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid var(--contour)', display: 'flex', flexDirection: 'column', gap: 10, fontSize: 14 }}>
            <div className="recap__ligne"><span>Sous-total</span><span>{subtotal} DT</span></div>
            <div className="recap__ligne"><span>Livraison</span><span>{livraison ? livraison + ' DT' : 'Offerte'}</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, fontSize: 18, fontWeight: 600 }}><span>Total</span><span>{subtotal + livraison} DT</span></div>
          </div>
        </aside>
      </div>
    </main>
  );
}
