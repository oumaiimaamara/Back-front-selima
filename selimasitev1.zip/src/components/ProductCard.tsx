'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { LABELS, type ProductCardData } from '@/lib/catalog-types';
import { useCart } from './cart';
import { Coche, Sac } from './icons';

export default function ProductCard({ p, height = 520, showMeta = true }: { p: ProductCardData; height?: number; showMeta?: boolean }) {
  const { add } = useCart();
  const [open, setOpen] = useState(false);
  const [done, setDone] = useState('');
  const ref = useRef<HTMLDivElement>(null);
  const label = p.soldOut ? 'Épuisé' : LABELS[p.label];

  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', esc);
    return () => { document.removeEventListener('mousedown', close); document.removeEventListener('keydown', esc); };
  }, [open]);

  const choisir = (size: string) => {
    add({ productId: p.id, slug: p.slug, name: p.name, size, price: p.price, image: p.image });
    setOpen(false);
    setDone(size);
    setTimeout(() => setDone(''), 2500);
  };

  return (
    <article className="carte">
      <Link href={'/produit/' + p.slug} className="carte__photo" style={{ height }} aria-label={p.name}>
        {p.image ? <img src={p.image} alt={p.imageAlt} /> : null}
        {label && <span className={'puce' + (p.label === 'edition_limitee' || p.soldOut ? ' puce--sombre' : '')}>{label}</span>}
      </Link>
      <div className="carte__encoche" ref={ref}>
        {!p.soldOut && (
          <button type="button" className="carte__ajout" aria-label={'Ajouter ' + p.name + ' au panier'} aria-expanded={open} onClick={() => setOpen((o) => !o)}>
            {done ? <Coche size={18} /> : <Sac />}
          </button>
        )}
        {open && (
          <div className="choix-rapide" role="dialog" aria-label={'Choisir une taille pour ' + p.name}>
            <p>Choisissez une taille</p>
            <div>
              {p.sizes.map((s) => (
                <button key={s.size} type="button" className="pilule" disabled={s.stock <= 0} onClick={() => choisir(s.size)}>{s.size}</button>
              ))}
            </div>
          </div>
        )}
      </div>
      <div className="carte__infos">
        <Link href={'/produit/' + p.slug} className="carte__nom">{p.name}</Link>
        <span className="carte__prix">{p.comparePrice ? <s>{p.comparePrice} DT</s> : null}{p.price} DT</span>
      </div>
      {done ? (
        <div className="carte__sous" role="status" style={{ color: 'var(--titre)', fontWeight: 600 }}>Ajouté au panier · {done} — <Link href="/panier" style={{ textDecoration: 'underline' }}>voir</Link></div>
      ) : (
        <div className="carte__sous">{p.subtitle}</div>
      )}
      {showMeta && (
        <div className="carte__meta">
          {p.colors.map((c) => <span key={c.name} className="pastille" style={{ background: c.hex }} title={c.name} />)}
          <span style={{ marginLeft: p.colors.length ? 6 : 0 }}>{p.sizes.map((s) => s.size.replace(' ans', '')).join(' · ')} ans</span>
          {p.lowStock && !p.soldOut && <span className="alerte-stock" style={{ marginLeft: 8 }}>Plus que quelques pièces</span>}
        </div>
      )}
    </article>
  );
}
