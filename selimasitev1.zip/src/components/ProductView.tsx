'use client';

import Link from 'next/link';
import { useState } from 'react';
import { LABELS, type ProductDetail } from '@/lib/catalog-types';
import { useCart } from './cart';
import SizeGuidePanel from './SizeGuidePanel';
import { Billet, Bulle, Cadeau, Camion, Coche, Droite, FlecheGras, Gauche, Sac } from './icons';

export default function ProductView({ p, whatsapp, shippingFee, shippingDelay, threshold }: { p: ProductDetail; whatsapp: string; shippingFee: number; shippingDelay: string; threshold: number }) {
  const { add } = useCart();
  const images = p.images.length ? p.images : [{ url: '', alt: p.name }];
  const [photo, setPhoto] = useState(0);
  const [taille, setTaille] = useState<string | null>(null);
  const [qte, setQte] = useState(1);
  const [erreur, setErreur] = useState(false);
  const [ajoute, setAjoute] = useState(false);
  const [guide, setGuide] = useState(false);

  const stockTaille = p.sizes.find((s) => s.size === taille)?.stock ?? 0;
  const label = p.soldOut ? 'Épuisé' : LABELS[p.label];

  const ajouter = () => {
    if (!taille) { setErreur(true); return; }
    add({ productId: p.id, slug: p.slug, name: p.name, size: taille, price: p.price, image: p.image }, qte);
    setAjoute(true);
  };

  return (
    <>
      <div className="produit">
        {/* Galerie */}
        <div className="galerie">
          <div className="galerie__vignettes">
            {images.map((im, i) => (
              <button key={i} type="button" onClick={() => setPhoto(i)} aria-label={'Voir la photo ' + (i + 1)} aria-current={photo === i} className="galerie__vignette">
                {im.url && <img src={im.url} alt="" />}
              </button>
            ))}
          </div>
          <div className="galerie__grande">
            {images[photo].url && <img src={images[photo].url} alt={images[photo].alt} />}
            {label && <span className={'puce' + (p.label === 'edition_limitee' || p.soldOut ? ' puce--sombre' : '')}>{label}</span>}
            {images.length > 1 && (
              <div className="galerie__fleches">
                <button type="button" onClick={() => setPhoto((photo - 1 + images.length) % images.length)} aria-label="Photo précédente"><Gauche /></button>
                <button type="button" onClick={() => setPhoto((photo + 1) % images.length)} aria-label="Photo suivante"><Droite /></button>
              </div>
            )}
          </div>
        </div>

        {/* Infos */}
        <div className="produit__infos">
          <div className="surtitre">Collection automne</div>
          <h1 className="produit__nom">{p.name}</h1>
          <p style={{ margin: '8px 0 0', fontSize: 16, color: 'var(--texte-doux)' }}>{p.subtitle}</p>
          <div style={{ marginTop: 20, fontSize: 30, fontWeight: 600 }}>
            {p.comparePrice ? <s style={{ fontSize: 20, fontWeight: 400, color: 'var(--texte-doux)', marginRight: 10 }}>{p.comparePrice} DT</s> : null}
            {p.price} DT
          </div>
          <p style={{ margin: '22px 0 0', fontSize: 16, lineHeight: 1.65, maxWidth: 520 }}>{p.description}</p>

          {p.colors.length > 0 && (
            <div style={{ marginTop: 28, display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--titre)' }}>Couleur</span>
              <span style={{ display: 'flex', gap: 4 }}>{p.colors.map((c) => <span key={c.name} className="pastille" style={{ width: 22, height: 22, background: c.hex }} />)}</span>
              <span style={{ fontSize: 14, color: 'var(--texte-doux)' }}>{p.colors.map((c) => c.name).join(' & ')}</span>
            </div>
          )}

          <div style={{ marginTop: 26, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--titre)' }}>Taille {taille && <span style={{ fontWeight: 400, color: 'var(--texte-doux)' }}>· {taille}</span>}</span>
            <button type="button" className="lien" onClick={() => setGuide(true)}>Guide des tailles</button>
          </div>
          <div style={{ marginTop: 12, display: 'flex', gap: 8, flexWrap: 'wrap' }} role="group" aria-label="Choisir une taille">
            {p.sizes.map((s) => (
              <button key={s.size} type="button" className="pilule pilule--grande" aria-pressed={taille === s.size} disabled={s.stock <= 0}
                onClick={() => { setTaille(s.size); setErreur(false); setAjoute(false); setQte(1); }}>
                {s.size}
              </button>
            ))}
          </div>
          {erreur && <p className="erreur" role="alert" style={{ marginTop: 10 }}>Choisissez une taille pour continuer.</p>}
          {taille && stockTaille > 0 && stockTaille < threshold && <p className="alerte-stock" style={{ margin: '10px 0 0' }}>Plus que {stockTaille} pièce{stockTaille > 1 ? 's' : ''} dans cette taille</p>}

          {p.soldOut ? (
            <p style={{ marginTop: 26, fontSize: 16, fontWeight: 600 }}>Cette pièce est épuisée.</p>
          ) : (
            <div style={{ marginTop: 26, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <div className="quantite">
                <button type="button" onClick={() => setQte(Math.max(1, qte - 1))} aria-label="Diminuer la quantité">−</button>
                <span aria-live="polite">{qte}</span>
                <button type="button" onClick={() => setQte(Math.min(taille ? Math.min(10, stockTaille) : 10, qte + 1))} aria-label="Augmenter la quantité">+</button>
              </div>
              <button type="button" className="bouton-plein" style={{ flex: 1, minWidth: 240 }} onClick={ajouter}>
                <Sac /> Ajouter au panier · {p.price * qte} DT
              </button>
            </div>
          )}

          {ajoute && (
            <div role="status" className="ajoute">
              <span style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15, fontWeight: 500 }}>
                <span className="rond-rose" style={{ width: 28, height: 28 }}><Coche /></span>Ajouté au panier · taille {taille}
              </span>
              <Link href="/panier" className="lien" style={{ fontSize: 15, fontWeight: 600 }}>Voir mon panier</Link>
            </div>
          )}

          <a href={'https://wa.me/216' + whatsapp.replace(/\D/g, '') + '?text=' + encodeURIComponent('Bonjour, une question sur « ' + p.name + ' » :')} target="_blank" rel="noopener" className="bouton-contour" style={{ marginTop: 10, width: '100%' }}>
            <Bulle size={18} /> Une question ? Écrivez-nous sur WhatsApp
          </a>

          <div className="rassurance">
            <div><Camion /> Livraison en {shippingDelay} partout en Tunisie · {shippingFee} DT</div>
            <div><Billet /> Paiement à la livraison</div>
            <div><Cadeau /> Livré dans sa pochette en coton écru, prêt à offrir</div>
          </div>

          <div style={{ marginTop: 32, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <details className="repli" open>
              <summary>Détails de la pièce<span className="rond-rose"><FlecheGras /></span></summary>
              <ul style={{ paddingLeft: 48 }}>{p.details.map((d) => <li key={d} style={{ lineHeight: 1.8 }}>{d}</li>)}</ul>
            </details>
            <details className="repli">
              <summary>Matières &amp; entretien<span className="rond-rose"><FlecheGras /></span></summary>
              <p>{p.materials.includes('Coton') && 'Coton : respirant, doux et hypoallergénique. '}{p.materials.includes('Lin') && 'Lin : souple, solide et durable.'}<br />{p.care || '[Conseils d’entretien à fournir.]'}</p>
            </details>
            <details className="repli">
              <summary>Livraison &amp; échanges<span className="rond-rose"><FlecheGras /></span></summary>
              <p>Livraison en {shippingDelay} partout en Tunisie pour {shippingFee} DT, paiement à la livraison. <Link href="/aide?rubrique=echanges" style={{ textDecoration: 'underline' }}>Voir les échanges</Link></p>
            </details>
          </div>
        </div>
      </div>

      {/* Barre d'achat mobile */}
      {!p.soldOut && (
        <div className="barre-mobile">
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 500 }}>{p.name} · {taille ?? 'choisir une taille'}</div>
            <div style={{ fontSize: 16, fontWeight: 600 }}>{p.price * qte} DT</div>
          </div>
          <button type="button" className="bouton-plein" style={{ height: 52, fontSize: 15, padding: '0 22px' }} onClick={() => { if (!taille) { setErreur(true); window.scrollTo({ top: 300, behavior: 'smooth' }); } else ajouter(); }}>Ajouter au panier</button>
        </div>
      )}

      {guide && <SizeGuidePanel onClose={() => setGuide(false)} whatsapp={whatsapp} />}
    </>
  );
}
