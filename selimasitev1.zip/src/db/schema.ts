import {
  boolean, integer, jsonb, pgEnum, pgTable, primaryKey, serial, text, timestamp,
} from 'drizzle-orm/pg-core';

export const orderStatus = pgEnum('order_status', ['nouvelle', 'confirmee', 'expediee', 'livree', 'annulee']);
export const productLabel = pgEnum('product_label', ['aucune', 'nouveau', 'edition_limitee']);

export type Color = { name: string; hex: string };

export const categories = pgTable('categories', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  slug: text('slug').notNull().unique(),
  image: text('image'),
  position: integer('position').notNull().default(0),
  visible: boolean('visible').notNull().default(true),
});

export const products = pgTable('products', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  subtitle: text('subtitle').notNull().default(''),
  price: integer('price').notNull(), // en dinars
  comparePrice: integer('compare_price'), // prix barré facultatif
  description: text('description').notNull().default(''),
  details: text('details').notNull().default(''), // une ligne par détail
  care: text('care').notNull().default(''),
  label: productLabel('label').notNull().default('aucune'),
  materials: jsonb('materials').$type<string[]>().notNull().default([]),
  colors: jsonb('colors').$type<Color[]>().notNull().default([]),
  published: boolean('published').notNull().default(false),
  position: integer('position').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const productImages = pgTable('product_images', {
  id: serial('id').primaryKey(),
  productId: integer('product_id').notNull().references(() => products.id, { onDelete: 'cascade' }),
  url: text('url').notNull(),
  alt: text('alt').notNull().default(''),
  position: integer('position').notNull().default(0),
});

export const productSizes = pgTable('product_sizes', {
  id: serial('id').primaryKey(),
  productId: integer('product_id').notNull().references(() => products.id, { onDelete: 'cascade' }),
  size: text('size').notNull(), // ex. « 4 ans »
  stock: integer('stock').notNull().default(0),
  position: integer('position').notNull().default(0),
});

export const productCategories = pgTable('product_categories', {
  productId: integer('product_id').notNull().references(() => products.id, { onDelete: 'cascade' }),
  categoryId: integer('category_id').notNull().references(() => categories.id, { onDelete: 'cascade' }),
}, (t) => ({ pk: primaryKey({ columns: [t.productId, t.categoryId] }) }));

export const slides = pgTable('slides', {
  id: serial('id').primaryKey(),
  url: text('url').notNull(),
  alt: text('alt').notNull().default(''),
  position: integer('position').notNull().default(0),
});

export const orders = pgTable('orders', {
  id: serial('id').primaryKey(),
  number: text('number').notNull().unique(),
  status: orderStatus('status').notNull().default('nouvelle'),
  firstName: text('first_name').notNull(),
  lastName: text('last_name').notNull(),
  phone: text('phone').notNull(),
  email: text('email'),
  address: text('address').notNull(),
  city: text('city').notNull(),
  governorate: text('governorate').notNull(),
  note: text('note'),
  subtotal: integer('subtotal').notNull(),
  shipping: integer('shipping').notNull(),
  total: integer('total').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const orderItems = pgTable('order_items', {
  id: serial('id').primaryKey(),
  orderId: integer('order_id').notNull().references(() => orders.id, { onDelete: 'cascade' }),
  productId: integer('product_id').references(() => products.id, { onDelete: 'set null' }),
  productName: text('product_name').notNull(),
  size: text('size').notNull(),
  unitPrice: integer('unit_price').notNull(),
  quantity: integer('quantity').notNull(),
});

export const messages = pgTable('messages', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  phone: text('phone').notNull(),
  body: text('body').notNull(),
  read: boolean('read').notNull().default(false),
  handled: boolean('handled').notNull().default(false),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const settings = pgTable('settings', {
  key: text('key').primaryKey(),
  value: jsonb('value').notNull(),
});

export const adminUsers = pgTable('admin_users', {
  id: serial('id').primaryKey(),
  username: text('username').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
});
