# selima — boutique en ligne

Site e-commerce de **selima** (vêtements pour filles de 2 à 6 ans), en Next.js 14 avec une base Postgres (Neon) et déployé sur Vercel.

## Démarrer en local

```bash
npm install
cp .env.example .env.local      # renseigner DATABASE_URL
npm run db:push                 # crée les tables
ADMIN_PASSWORD=motdepasse npm run db:seed   # catégories, 2 produits, slider, compte admin
npm run dev
```

## Mise en ligne sur Vercel

1. Importer ce dépôt dans Vercel (framework : Next.js).
2. Onglet **Storage** → créer une base **Neon Postgres** et la relier au projet : `DATABASE_URL` est ajoutée automatiquement.
3. En local, avec la même `DATABASE_URL` : `npm run db:push` puis `ADMIN_PASSWORD=... npm run db:seed`.
4. Relier le domaine **selimaclothing.com** dans Vercel → Settings → Domains.

## Organisation

- `src/app/(boutique)` : accueil, boutique, fiche produit, aide, nos matières
- `src/app/(achat)` : panier, livraison, confirmation
- `src/app/admin` : espace de gestion (phase 2)
- `src/db/schema.ts` : tables (produits, tailles & stock, catégories, slider, commandes, messages, réglages)
- `src/lib/actions.ts` : enregistrement des commandes (vérification du stock) et des messages
- `src/lib/settings.ts` : réglages modifiables (livraison, seuil de stock bas, textes de l’accueil, FAQ)

## Contenus à fournir

Mesures du guide des tailles (`src/components/SizeTable.tsx`), conseils d’entretien, politique d’échange, mentions légales, e-mail de contact, stock réel du set.
